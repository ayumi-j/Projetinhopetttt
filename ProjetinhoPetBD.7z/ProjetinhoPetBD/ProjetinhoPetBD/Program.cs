﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace ProjetinhoPetBD
{
    class Program
    {
        static void Main(string[] args)
        {
            string op;
            Cadastro c = new Cadastro();
            Menu m = new Menu();
            marca me = new marca();
            Deletar d = new Deletar();
            Alterar a = new Alterar();

            op = Console.ReadLine();

            do
            {
                op = m.menu();
                switch (op)
                {
                    case "1":
                        c.cadpet();

                        break;
                    case "3":
                        c.cadpessoa();
                        break;
                    case "5":
                        me.marcahora();
                        break;
                    case "4":
                        c.visucadpessoa();
                        break;
                    case "2":
                        c.visucadpet();
                        break;
                    case "6":
                        me.visuhora();
                        break;
                    case "5621":
                        d.deletpet();
                        break;
                    case "5622":
                        d.deletcon();
                        break;
                    case "2536":
                        d.deletpes();
                        break;
                    case "27":
                        a.altpes();
                        break;
                    case "25":
                        a.altpet();
                        break;

                    case "S":
                        Console.WriteLine("Encerrando o programa");
                        break;
                    default:
                        Console.WriteLine("Opcao invalida!");
                        break;
                }
            } while (op != "S");
        }
    }
}
